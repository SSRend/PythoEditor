import pygame
import os
import cv2
import numpy as np

def run_edit_mode(screen, image_path):
    running = True
    clock = pygame.time.Clock()

    def convert_to_rgb(image):
        if image.get_flags() & pygame.SRCALPHA:
            return image.convert_alpha()
        return image.convert()

    try:
        original_image = pygame.image.load(image_path)
        original_image = convert_to_rgb(original_image)
    except Exception as e:
        print("이미지 로드 실패:", e)
        return

    font = pygame.font.Font(os.path.join("assets", "SCDream7.otf"), 32)
    bg_image = pygame.image.load(os.path.join("assets", "edit_mode.png")).convert()
    
    pygame.mixer.init()
    click_sound = pygame.mixer.Sound(os.path.join("assets", "click.wav"))

    image_history = [original_image.copy()]
    current_index = 0
    save_message_timer = 0

    working_image = image_history[current_index].copy()
    selected_feature = None

    rotation_angle = 0
    angle_input_text = "0"
    angle_input_rect = pygame.Rect(400, 900, 100, 40)
    angle_input_active = False

    width_input_text = ""
    height_input_text = ""
    width_input_rect = pygame.Rect(400, 900, 100, 40)
    height_input_rect = pygame.Rect(700, 900, 100, 40)
    width_input_active = False
    height_input_active = False
    
    blur_strength_buttons = {
    "약함": pygame.Rect(300, 900, 100, 40),
    "중간": pygame.Rect(420, 900, 100, 40),
    "강함": pygame.Rect(540, 900, 100, 40)
    }
    
    channel_buttons = {
    "R": pygame.Rect(300, 900, 100, 40),
    "G": pygame.Rect(420, 900, 100, 40),
    "B": pygame.Rect(540, 900, 100, 40)
    }
    
    flip_buttons = {
    "좌우 반전": pygame.Rect(300, 900, 160, 40),
    "상하 반전": pygame.Rect(500, 900, 160, 40)
    }

    brightness_value = 0  # 초기 밝기
    brightness_slider_rect = pygame.Rect(400, 910, 300, 10)
    brightness_handle_rect = pygame.Rect(0, 900, 20, 30)  # 초기 위치는 후에 계산
    brightness_dragging = False

    def pygame_to_cv(surface):
        """Pygame Surface → OpenCV (NumPy 배열, BGR)"""
        array = pygame.surfarray.array3d(surface)  # shape: (width, height, 3)
        array = np.transpose(array, (1, 0, 2))     # transpose to (height, width, 3)
        return cv2.cvtColor(array, cv2.COLOR_RGB2BGR)

    def cv_to_pygame(array):
        """OpenCV (BGR NumPy 배열) → Pygame Surface"""
        array = cv2.cvtColor(array, cv2.COLOR_BGR2RGB)
        array = np.transpose(array, (1, 0, 2))  # transpose to (width, height, 3)
        return pygame.surfarray.make_surface(array).convert()

    def get_saved_image():
        return image_history[current_index]

    def get_scaled_image(image):
        return pygame.transform.scale(image, (720, 720))

    def apply_grayscale(image):
        image = convert_to_rgb(image)
        # Pygame Surface → OpenCV 이미지 (RGB → BGR)
        cv_image = pygame.surfarray.array3d(image)
        cv_image = cv2.cvtColor(np.transpose(cv_image, (1, 0, 2)), cv2.COLOR_RGB2GRAY)
        # 그레이 이미지를 다시 RGB로 변환 (3채널로 만들어야 Pygame이 렌더링 가능)
        gray_bgr = cv2.cvtColor(cv_image, cv2.COLOR_GRAY2RGB)
        # OpenCV → Pygame Surface (좌우 반전 방지 위해 다시 transpose)
        return pygame.surfarray.make_surface(np.transpose(gray_bgr, (1, 0, 2))).convert()

    def apply_rotation(image, angle):
        image = convert_to_rgb(image)
        cv_img = pygame_to_cv(image)
        h, w = cv_img.shape[:2]
        center = (w // 2, h // 2)
        rot_matrix = cv2.getRotationMatrix2D(center, angle, 1.0)
        rotated = cv2.warpAffine(cv_img, rot_matrix, (w, h))
        return cv_to_pygame(rotated)

    def apply_resize(image, new_w, new_h):
        image = convert_to_rgb(image)
        cv_img = pygame_to_cv(image)
        resized = cv2.resize(cv_img, (new_w, new_h), interpolation=cv2.INTER_LINEAR)
        return cv_to_pygame(resized)

    def apply_invert(image):
        image = convert_to_rgb(image)
        cv_img = pygame_to_cv(image)
        inverted = cv2.bitwise_not(cv_img)
        return cv_to_pygame(inverted)

    def apply_edge_detection(image):
        image = convert_to_rgb(image)
        cv_img = pygame_to_cv(image)

        # 자동으로 흑백 변환
        gray = cv2.cvtColor(cv_img, cv2.COLOR_BGR2GRAY)

        # Canny 엣지 검출 (threshold 값은 고정)
        edges = cv2.Canny(gray, 100, 200)

        # 단일 채널 이미지를 다시 3채널로 변환
        edges_bgr = cv2.cvtColor(edges, cv2.COLOR_GRAY2BGR)

        return cv_to_pygame(edges_bgr)

    def apply_blur(image, ksize):
        image = convert_to_rgb(image)
        cv_img = pygame_to_cv(image)
        blurred = cv2.GaussianBlur(cv_img, (ksize, ksize), 0)
        return cv_to_pygame(blurred)

    def apply_channel_split(image, channel):
        image = convert_to_rgb(image)
        cv_img = pygame_to_cv(image)
        
        b, g, r = cv2.split(cv_img)

        blank = np.zeros_like(b)
        if channel == "R":
            merged = cv2.merge([blank, blank, r])
        elif channel == "G":
            merged = cv2.merge([blank, g, blank])
        elif channel == "B":
            merged = cv2.merge([b, blank, blank])
        else:
            merged = cv_img

        return cv_to_pygame(merged)

    def apply_brightness(image, value):
        image = convert_to_rgb(image)
        cv_img = pygame_to_cv(image)
        hsv = cv2.cvtColor(cv_img, cv2.COLOR_BGR2HSV)
        h, s, v = cv2.split(hsv)
        v = np.clip(v.astype(np.int16) + value, 0, 255).astype(np.uint8)
        adjusted = cv2.merge([h, s, v])
        bgr = cv2.cvtColor(adjusted, cv2.COLOR_HSV2BGR)
        return cv_to_pygame(bgr)
    
    def apply_flip(image, mode):
        image = convert_to_rgb(image)
        cv_img = pygame_to_cv(image)
        if mode == "좌우 반전":
            flipped = cv2.flip(cv_img, 1)
        elif mode == "상하 반전":
            flipped = cv2.flip(cv_img, 0)
        else:
            flipped = cv_img
        return cv_to_pygame(flipped)

    feature_names = [
        "흑백 변환", "밝기 조절", "크기 조절", "회전",
        "대칭 반전", "색상 반전", "엣지 검출", "블러", "채널 분리"
    ]
    feature_buttons = []
    for i, name in enumerate(feature_names):
        btn_rect = pygame.Rect(1300, 175 + i * 60, 180, 50)
        feature_buttons.append((btn_rect, name))

    undo_button = pygame.Rect(1300, 175 + len(feature_names) * 60 + 20, 80, 50)
    redo_button = pygame.Rect(1400, 175 + len(feature_names) * 60 + 20, 80, 50)
    save_button = pygame.Rect(1300, undo_button.bottom + 20, 80, 50)
    exit_button = pygame.Rect(1400, undo_button.bottom + 20, 80, 50)

    while running:
        screen.blit(bg_image, (0, 0))
        screen.blit(get_scaled_image(working_image), (300, 160))

        for rect, label in feature_buttons:
            pygame.draw.rect(screen, (100, 140, 190), rect, border_radius=8)
            if selected_feature == label:
                pygame.draw.rect(screen, (255, 255, 255), rect, 3, border_radius=8)
            text = font.render(label, True, (255, 255, 255))
            screen.blit(text, (rect.x + 10, rect.y + 10))

        if selected_feature == "회전":
            screen.blit(font.render("각도:", True, (255, 255, 255)), (300, 900))
            pygame.draw.rect(screen, (255, 255, 255) if angle_input_active else (200, 200, 200), angle_input_rect, 2)
            screen.blit(font.render(angle_input_text, True, (255, 255, 255)),
                        (angle_input_rect.x + 5, angle_input_rect.y + 5))

        if selected_feature == "크기 조절":
            screen.blit(font.render("가로:", True, (255, 255, 255)), (300, 900))
            screen.blit(font.render("세로:", True, (255, 255, 255)), (600, 900))
            pygame.draw.rect(screen, (255, 255, 255) if width_input_active else (200, 200, 200), width_input_rect, 2)
            pygame.draw.rect(screen, (255, 255, 255) if height_input_active else (200, 200, 200), height_input_rect, 2)
            screen.blit(font.render(width_input_text, True, (255, 255, 255)),
                        (width_input_rect.x + 5, width_input_rect.y + 5))
            screen.blit(font.render(height_input_text, True, (255, 255, 255)),
                        (height_input_rect.x + 5, height_input_rect.y + 5))

        if selected_feature == "블러":
            for label, rect in blur_strength_buttons.items():
                pygame.draw.rect(screen, (160, 160, 160), rect, border_radius=8)
                text = font.render(label, True, (255, 255, 255))
                screen.blit(text, (rect.x + 10, rect.y + 5))

        if selected_feature == "채널 분리":
            for label, rect in channel_buttons.items():
                pygame.draw.rect(screen, (160, 160, 160), rect, border_radius=8)
                text = font.render(label, True, (255, 255, 255))
                screen.blit(text, (rect.x + 10, rect.y + 5))
        
        if selected_feature == "밝기 조절":
            brightness_label = font.render("밝기:", True, (255, 255, 255))
            screen.blit(brightness_label, (brightness_slider_rect.x - 100, brightness_slider_rect.y - 10))
            # 바
            pygame.draw.rect(screen, (180, 180, 180), brightness_slider_rect)
            # 핸들 위치
            handle_x = brightness_slider_rect.x + int((brightness_value + 255) / 510 * brightness_slider_rect.width)
            brightness_handle_rect.x = handle_x - brightness_handle_rect.width // 2
            pygame.draw.rect(screen, (100, 140, 190), brightness_handle_rect)
            screen.blit(font.render(f"{brightness_value}", True, (255, 255, 255)), (brightness_slider_rect.right + 10, brightness_slider_rect.y - 10))

        if selected_feature == "대칭 반전":
            for label, rect in flip_buttons.items():
                pygame.draw.rect(screen, (160, 160, 160), rect, border_radius=8)
                text = font.render(label, True, (255, 255, 255))
                screen.blit(text, (rect.x + 10, rect.y + 5))

        pygame.draw.rect(screen, (120, 120, 120), undo_button, border_radius=8)
        pygame.draw.rect(screen, (120, 120, 120), redo_button, border_radius=8)
        screen.blit(font.render("←", True, (255, 255, 255)), (undo_button.x + 10, undo_button.y + 10))
        screen.blit(font.render("→", True, (255, 255, 255)), (redo_button.x + 10, redo_button.y + 10))

        pygame.draw.rect(screen, (0, 120, 90), save_button, border_radius=8)
        pygame.draw.rect(screen, (180, 80, 80), exit_button, border_radius=8)
        screen.blit(font.render("저장", True, (255, 255, 255)), (save_button.x + 10, save_button.y + 10))
        screen.blit(font.render("종료", True, (255, 255, 255)), (exit_button.x + 10, exit_button.y + 10))

        if save_message_timer > 0:
            screen.blit(font.render("저장됨!", True, (255, 255, 255)), (save_button.x, save_button.bottom + 10))
            save_message_timer -= 1

        pygame.display.flip()

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False

            elif event.type == pygame.MOUSEBUTTONUP:
                brightness_dragging = False

            elif event.type == pygame.MOUSEMOTION:
                if brightness_dragging and selected_feature == "밝기 조절":
                    x = max(brightness_slider_rect.left, min(event.pos[0], brightness_slider_rect.right))
                    brightness_value = int(((x - brightness_slider_rect.left) / brightness_slider_rect.width) * 510 - 255)
                    working_image = apply_brightness(get_saved_image(), brightness_value)

            elif event.type == pygame.MOUSEBUTTONDOWN:
                # 기능 버튼 처리
                for rect, label in feature_buttons:
                    if rect.collidepoint(event.pos):
                        click_sound.play()
                        if label != selected_feature:
                            working_image = get_saved_image().copy()
                            if label == "흑백 변환":
                                working_image = apply_grayscale(get_saved_image())
                            elif label == "회전":
                                try:
                                    angle = int(angle_input_text)
                                except:
                                    angle = 0
                                working_image = apply_rotation(get_saved_image(), angle)
                            elif label == "크기 조절":
                                w, h = get_saved_image().get_size()
                                width_input_text = str(w)
                                height_input_text = str(h)
                            elif label == "색상 반전":
                                working_image = apply_invert(get_saved_image())
                            elif label == "엣지 검출":
                                working_image = apply_edge_detection(get_saved_image())
                            elif label == "밝기 조절":
                                pass  # 향후 밝기 조절 기능 처리
                            elif label == "대칭 반전":
                                pass  # 향후 flip 기능 처리
                        selected_feature = label

                # ✅ 블러 강도 버튼 처리 (기능 선택 이후 클릭되는 부분)
                if selected_feature == "블러":
                    for label, rect in blur_strength_buttons.items():
                        if rect.collidepoint(event.pos):
                            click_sound.play()
                            if label == "약하게":
                                working_image = apply_blur(get_saved_image(), 3)
                            elif label == "중간":
                                working_image = apply_blur(get_saved_image(), 5)
                            elif label == "강하게":
                                working_image = apply_blur(get_saved_image(), 7)

                if selected_feature == "채널 분리":
                    for label, rect in channel_buttons.items():
                        if rect.collidepoint(event.pos):
                            click_sound.play()
                            working_image = apply_channel_split(get_saved_image(), label)

                if selected_feature == "대칭 반전":
                    for label, rect in flip_buttons.items():
                        if rect.collidepoint(event.pos):
                            click_sound.play()
                            working_image = apply_flip(get_saved_image(), label)

                angle_input_active = angle_input_rect.collidepoint(event.pos)
                width_input_active = width_input_rect.collidepoint(event.pos)
                height_input_active = height_input_rect.collidepoint(event.pos)

                if undo_button.collidepoint(event.pos) and current_index > 0:
                    click_sound.play()
                    current_index -= 1
                    working_image = image_history[current_index].copy()
                    print("Undo")

                if redo_button.collidepoint(event.pos) and current_index < len(image_history) - 1:
                    click_sound.play()
                    current_index += 1
                    working_image = image_history[current_index].copy()
                    print("Redo")

                if save_button.collidepoint(event.pos):
                    click_sound.play()
                    # 저장 전에 되돌리기 이후 기록 제거
                    image_history = image_history[:current_index + 1]
                    image_history.append(working_image.copy())
                    current_index += 1
                    pygame.image.save(working_image, image_path)
                    save_message_timer = 120
                    print("저장 완료!")

                elif exit_button.collidepoint(event.pos):
                    click_sound.play()
                    running = False

                if selected_feature == "밝기 조절" and brightness_handle_rect.collidepoint(event.pos):
                    brightness_dragging = True

            elif event.type == pygame.KEYDOWN:
                if angle_input_active and selected_feature == "회전":
                    if event.key == pygame.K_RETURN:
                        angle_input_active = False
                        try:
                            angle = int(angle_input_text)
                        except:
                            angle = 0
                        working_image = apply_rotation(get_saved_image(), angle)
                    elif event.key == pygame.K_BACKSPACE:
                        angle_input_text = angle_input_text[:-1]
                    elif event.unicode.isdigit() or (event.unicode == '-' and angle_input_text == ""):
                        angle_input_text += event.unicode

                if width_input_active and selected_feature == "크기 조절":
                    if event.key == pygame.K_RETURN:
                        try:
                            w = int(width_input_text)
                            h = int(height_input_text)
                            working_image = apply_resize(get_saved_image(), w, h)
                        except:
                            pass
                        width_input_active = False
                    elif event.key == pygame.K_BACKSPACE:
                        width_input_text = width_input_text[:-1]
                    elif event.unicode.isdigit():
                        width_input_text += event.unicode

                if height_input_active and selected_feature == "크기 조절":
                    if event.key == pygame.K_RETURN:
                        try:
                            w = int(width_input_text)
                            h = int(height_input_text)
                            working_image = apply_resize(get_saved_image(), w, h)
                        except:
                            pass
                        height_input_active = False
                    elif event.key == pygame.K_BACKSPACE:
                        height_input_text = height_input_text[:-1]
                    elif event.unicode.isdigit():
                        height_input_text += event.unicode

        clock.tick(60)
