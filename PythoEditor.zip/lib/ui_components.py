# lib/ui_components.py
import pygame

class TextInput:
    def __init__(self, rect, font, text=''):
        self.rect = pygame.Rect(rect)
        self.font = font
        self.text = text
        self.active = False
        self.color_inactive = (180, 180, 180)
        self.color_active = (50, 120, 200)
        self.color = self.color_inactive

    def handle_event(self, event):
        if event.type == pygame.MOUSEBUTTONDOWN:
            self.active = self.rect.collidepoint(event.pos)
            self.color = self.color_active if self.active else self.color_inactive
        elif event.type == pygame.KEYDOWN and self.active:
            if event.key == pygame.K_RETURN:
                self.active = False
            elif event.key == pygame.K_BACKSPACE:
                self.text = self.text[:-1]
            elif event.unicode.isdigit():
                self.text += event.unicode

    def draw(self, screen):
        pygame.draw.rect(screen, self.color, self.rect, 2)
        txt_surf = self.font.render(self.text, True, (0, 0, 0))
        screen.blit(txt_surf, (self.rect.x + 5, self.rect.y + 10))

    def get_value(self):
        return self.text
