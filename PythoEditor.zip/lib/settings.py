import json
import os

CONFIG_PATH = os.path.join("data", "config.json")

# 기본 설정
DEFAULT_SETTINGS = {
    "volume": 0.5,                      # 효과음 볼륨 (0.0 ~ 1.0)
    "mute": False,                      # 음소거 여부
    "last_opened_image": None,         # 마지막 열었던 이미지 경로
    "image_sorting": "name"            # 정렬 기준: name / date / size
}


def init_settings():
    """설정을 로드하거나 기본값으로 초기화"""
    if not os.path.exists(CONFIG_PATH):
        save_settings(DEFAULT_SETTINGS)
        return DEFAULT_SETTINGS.copy()
    else:
        try:
            with open(CONFIG_PATH, "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception as e:
            print(f"⚠️ 설정 파일을 불러오는 데 실패했습니다: {e}")
            return DEFAULT_SETTINGS.copy()


def save_settings(settings):
    """설정을 저장"""
    try:
        os.makedirs(os.path.dirname(CONFIG_PATH), exist_ok=True)
        with open(CONFIG_PATH, "w", encoding="utf-8") as f:
            json.dump(settings, f, indent=4, ensure_ascii=False)
    except Exception as e:
        print(f"⚠️ 설정 파일 저장 실패: {e}")
