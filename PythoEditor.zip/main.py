import pygame
import sys

from lib.settings import init_settings
from lib.mainMenu import MainMenu

def main():
    # 1. 파이게임 초기화
    pygame.init()

    # 2. 사용자 설정 로드
    settings = init_settings()

    # 3. 윈도우 크기 설정 (기본값 1920x1080)
    window_size = settings.get('window_size', (1920, 1080))
    screen = pygame.display.set_mode(window_size)
    pygame.display.set_caption("Pytho Editor")

    # 4. 메인 메뉴 진입
    menu = MainMenu(screen, settings)
    menu.run()

    # 5. 종료 처리
    pygame.mixer.music.stop()
    pygame.quit()
    sys.exit()

if __name__ == "__main__":
    main()
