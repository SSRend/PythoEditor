
        while self.running: