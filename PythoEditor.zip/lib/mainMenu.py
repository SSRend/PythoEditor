import pygame
import os
import colorsys
from lib.edit_mode import run_edit_mode

# 텍스트 입력 박스 클래스
class TextInput:
    def __init__(self, rect, font, text=''):
        self.rect = pygame.Rect(rect)
        self.font = font
        self.text = text
        self.active = False
        self.color_inactive = (180, 180, 180)
        self.color_active = (50, 120, 200)
        self.color = self.color_inactive
        self.dirty = False

    def handle_event(self, event):
        if event.type == pygame.MOUSEBUTTONDOWN:
            self.active = self.rect.collidepoint(event.pos)
            self.color = self.color_active if self.active else self.color_inactive
        elif event.type == pygame.KEYDOWN and self.active:
            if event.key == pygame.K_RETURN:
                self.active = False
                self.dirty = True
            elif event.key == pygame.K_BACKSPACE:
                self.text = self.text[:-1]
            elif event.key == pygame.K_v and (pygame.key.get_mods() & pygame.KMOD_CTRL):
                try:
                    self.text += pygame.scrap.get(pygame.SCRAP_TEXT).decode()
                except:
                    pass
            elif event.unicode.isprintable():
                self.text += event.unicode

    def draw(self, screen):
        pygame.draw.rect(screen, self.color, self.rect, 2)
        txt_surf = self.font.render(self.text, True, (0, 0, 0))
        screen.blit(txt_surf, (self.rect.x + 5, self.rect.y + 10))

    def get_value(self):
        return self.text

    def is_active(self):
        return self.active

def clamp(value, min_val, max_val):
    return max(min_val, min(max_val, value))

def rgb_to_hsv(r, g, b):
    h, s, v = colorsys.rgb_to_hsv(r / 255, g / 255, b / 255)
    return [int(h * 360 + 0.5), int(s * 100 + 0.5), int(v * 100 + 0.5)]

def hsv_to_rgb(h, s, v):
    r, g, b = colorsys.hsv_to_rgb(h / 360, s / 100, v / 100)
    return [int(r * 255 + 0.5), int(g * 255 + 0.5), int(b * 255 + 0.5)]

class MainMenu:
    def __init__(self, screen, settings):
        self.screen = screen
        self.settings = settings
        self.running = True
        self.message_timer = 0

        self.bg_image = pygame.image.load(os.path.join("assets", "title_screen.png")).convert()
        self.font = pygame.font.Font(os.path.join("assets", "SCDream7.otf"), 60)
        self.input_font = pygame.font.Font(os.path.join("assets", "SCDream7.otf"), 32)

        pygame.mixer.init()
        self.click_sound = pygame.mixer.Sound(os.path.join("assets", "click.wav"))
        
        if not pygame.mixer.music.get_busy():
            pygame.mixer.music.load(os.path.join("assets", "main_theme.wav"))
            pygame.mixer.music.play(-1)  # 무한 반복

        self.button_color = (60, 75, 100)
        self.button_hover_color = (90, 105, 130)
        self.text_color = (140, 160, 185)

        self.new_image_button_rect = pygame.Rect(1300, 375, 440, 140)
        self.edit_image_button_rect = pygame.Rect(1300, 565, 440, 140)
        self.close_button_rect = pygame.Rect(620, 210, 40, 40)
        self.confirm_button_rect = pygame.Rect(120, 700, 180, 70)
        self.delete_button_rect = pygame.Rect(320, 700, 180, 70)

        self.panel_mode = None
        self.selected_image_index = None

        self.inputs = {
            "width": TextInput((180, 315, 100, 50), self.input_font),
            "height": TextInput((435, 315, 100, 50), self.input_font),
            "hex": TextInput((280, 395, 180, 50), self.input_font),
            "r": TextInput((160, 475, 80, 50), self.input_font),
            "g": TextInput((300, 475, 80, 50), self.input_font),
            "b": TextInput((440, 475, 80, 50), self.input_font),
            "h": TextInput((200, 555, 80, 50), self.input_font),
            "s": TextInput((380, 555, 80, 50), self.input_font),
            "v": TextInput((560, 555, 80, 50), self.input_font)
        }

    def reset_inputs(self):
        defaults = {
            "width": "100", "height": "100",
            "r": "0", "g": "0", "b": "0",
            "h": "0", "s": "0", "v": "0",
            "hex": "#000000"
        }
        for k, v in defaults.items():
            self.inputs[k].text = v
            self.inputs[k].dirty = False

    def sync_color_fields(self):
        if any(self.inputs[c].dirty for c in ("r", "g", "b")):
            try:
                r = clamp(int(self.inputs["r"].text), 0, 255)
                g = clamp(int(self.inputs["g"].text), 0, 255)
                b = clamp(int(self.inputs["b"].text), 0, 255)
                h, s, v = rgb_to_hsv(r, g, b)
                self.inputs["h"].text = str(h)
                self.inputs["s"].text = str(s)
                self.inputs["v"].text = str(v)
                self.inputs["hex"].text = "#{:02X}{:02X}{:02X}".format(r, g, b)
            except:
                pass
            for c in ("r", "g", "b"):
                self.inputs[c].dirty = False

        elif any(self.inputs[c].dirty for c in ("h", "s", "v")):
            try:
                h = clamp(int(self.inputs["h"].text), 0, 360)
                s = clamp(int(self.inputs["s"].text), 0, 100)
                v = clamp(int(self.inputs["v"].text), 0, 100)
                r, g, b = hsv_to_rgb(h, s, v)
                self.inputs["r"].text = str(r)
                self.inputs["g"].text = str(g)
                self.inputs["b"].text = str(b)
                self.inputs["hex"].text = "#{:02X}{:02X}{:02X}".format(r, g, b)
            except:
                pass
            for c in ("h", "s", "v"):
                self.inputs[c].dirty = False

        elif self.inputs["hex"].dirty:
            try:
                hex_code = self.inputs["hex"].text.strip().lstrip('#')
                if len(hex_code) == 6:
                    r = int(hex_code[0:2], 16)
                    g = int(hex_code[2:4], 16)
                    b = int(hex_code[4:6], 16)
                    self.inputs["r"].text = str(r)
                    self.inputs["g"].text = str(g)
                    self.inputs["b"].text = str(b)
                    h, s, v = rgb_to_hsv(r, g, b)
                    self.inputs["h"].text = str(h)
                    self.inputs["s"].text = str(s)
                    self.inputs["v"].text = str(v)
            except:
                pass
            self.inputs["hex"].dirty = False

    def run(self):
        while self.running:
            self.handle_events()
            self.render()
            pygame.display.flip()

    def handle_events(self):
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                self.running = False
            elif event.type == pygame.MOUSEBUTTONDOWN:
                if self.new_image_button_rect.collidepoint(event.pos):
                    self.click_sound.play()
                    self.panel_mode = None if self.panel_mode == "new" else "new"
                    self.reset_inputs()
                elif self.edit_image_button_rect.collidepoint(event.pos):
                    self.click_sound.play()
                    self.panel_mode = None if self.panel_mode == "edit" else "edit"
                    self.selected_image_index = None
                elif self.close_button_rect.collidepoint(event.pos):
                    self.click_sound.play()
                    self.panel_mode = None
                elif self.panel_mode == "new" and self.confirm_button_rect.collidepoint(event.pos):
                    try:
                        width = clamp(int(self.inputs["width"].get_value()), 1, 2000)
                        height = clamp(int(self.inputs["height"].get_value()), 1, 2000)
                        r = clamp(int(self.inputs["r"].get_value()), 0, 255)
                        g = clamp(int(self.inputs["g"].get_value()), 0, 255)
                        b = clamp(int(self.inputs["b"].get_value()), 0, 255)
                        surface = pygame.Surface((width, height))
                        surface.fill((r, g, b))
                        os.makedirs("images", exist_ok=True)
                        for i in range(1, 21):
                            filename = f"images/{i}.png"
                            if not os.path.exists(filename):
                                pygame.image.save(surface, filename)
                                self.message_timer = 120
                                break
                    except Exception as e:
                        print("⚠️ 저장 실패:", e)

                elif self.panel_mode == "edit":
                    for idx in range(20):
                        x = 120 + (idx % 5) * 100
                        y = 320 + (idx // 5) * 90
                        rect = pygame.Rect(x, y, 80, 80)
                        if rect.collidepoint(event.pos):
                            self.selected_image_index = idx
                            self.click_sound.play()

                    if self.confirm_button_rect.collidepoint(event.pos):
                        if self.selected_image_index is not None:
                            img_path = f"images/{self.selected_image_index + 1}.png"
                            if os.path.exists(img_path):
                                print("편집 시작!")
                                run_edit_mode(self.screen, img_path)
                                self.panel_mode = None
                                self.selected_image_index = None

                    elif self.delete_button_rect.collidepoint(event.pos):
                        if self.selected_image_index is not None:
                            path = f"images/{self.selected_image_index + 1}.png"
                            if os.path.exists(path):
                                os.remove(path)
                                self.selected_image_index = None

            if self.panel_mode == "new":
                for input_box in self.inputs.values():
                    input_box.handle_event(event)
                self.sync_color_fields()

    def render(self):
        self.screen.blit(self.bg_image, (0, 0))
        mouse_pos = pygame.mouse.get_pos()

        if self.panel_mode in ("new", "edit"):
            pygame.draw.rect(self.screen, (233, 238, 247), (80, 200, 600, 600), border_radius=20)
            pygame.draw.rect(self.screen, (90, 105, 130), self.close_button_rect, border_radius=8)
            close_text = self.input_font.render("X", True, (233, 238, 247))
            self.screen.blit(close_text, (self.close_button_rect.x + 8, self.close_button_rect.y + 4))

        if self.panel_mode == "new":
            def draw_label(text, pos):
                label = self.input_font.render(text, True, (30, 30, 30))
                self.screen.blit(label, pos)

            draw_label("새 이미지 생성", (120, 230))
            draw_label("폭:", (120, 320)); draw_label("x", (300, 320)); draw_label("높이:", (340, 320))
            draw_label("RGB 코드:", (120, 400))
            draw_label("R:", (120, 480)); draw_label("G:", (260, 480)); draw_label("B:", (400, 480))
            draw_label("색상:", (120, 560)); draw_label("채도:", (300, 560)); draw_label("명도:", (480, 560))
            draw_label("색상 미리보기:", (120, 640))

            for input_box in self.inputs.values():
                input_box.draw(self.screen)

            try:
                r = clamp(int(self.inputs["r"].text), 0, 255)
                g = clamp(int(self.inputs["g"].text), 0, 255)
                b = clamp(int(self.inputs["b"].text), 0, 255)
            except:
                r, g, b = 0, 0, 0

            pygame.draw.rect(self.screen, (r, g, b), (350, 630, 60, 60), border_radius=10)
            pygame.draw.rect(self.screen, (100, 100, 100), (350, 630, 60, 60), 2)

            pygame.draw.rect(self.screen, (90, 105, 130), self.confirm_button_rect, border_radius=10)
            gen_text = self.input_font.render("생성", True, (233, 238, 247))
            self.screen.blit(gen_text, (170, 720))

        elif self.panel_mode == "edit":
            title = self.input_font.render("이미지 선택", True, (30, 30, 30))
            self.screen.blit(title, (120, 230))
            for idx in range(20):
                x = 120 + (idx % 5) * 100
                y = 320 + (idx // 5) * 90
                rect = pygame.Rect(x, y, 80, 80)
                path = f"images/{idx + 1}.png"
                if os.path.exists(path):
                    try:
                        img = pygame.image.load(path)
                        img = pygame.transform.scale(img, (80, 80))
                        self.screen.blit(img, (x, y))
                        if self.selected_image_index == idx:
                            pygame.draw.rect(self.screen, (90, 105, 130), rect, 4)
                    except:
                        pass
                else:
                    pygame.draw.rect(self.screen, (0, 0, 0), rect)
                    none_text = self.input_font.render("없음", True, (255, 255, 255))
                    self.screen.blit(none_text, (x + 5, y + 25))

            pygame.draw.rect(self.screen, (90, 105, 130), self.confirm_button_rect, border_radius=10)
            confirm_text = self.input_font.render("편집", True, (233, 238, 247))
            self.screen.blit(confirm_text, (self.confirm_button_rect.x + 50, self.confirm_button_rect.y + 20))

            pygame.draw.rect(self.screen, (90, 30, 30), self.delete_button_rect, border_radius=10)
            delete_text = self.input_font.render("삭제", True, (255, 255, 255))
            self.screen.blit(delete_text, (self.delete_button_rect.x + 50, self.delete_button_rect.y + 20))

        if self.message_timer > 0:
            msg = self.input_font.render("생성이 완료되었습니다!", True, (90, 105, 130))
            self.screen.blit(msg, (320, 720))
            self.message_timer -= 0.25

        for rect, text_str in [
            (self.new_image_button_rect, "새 이미지"),
            (self.edit_image_button_rect, "이미지 편집")
        ]:
            color = self.button_hover_color if rect.collidepoint(mouse_pos) else self.button_color
            pygame.draw.rect(self.screen, color, rect, border_radius=10)
            text = self.font.render(text_str, True, self.text_color)
            shadow = self.font.render(text_str, True, (30, 30, 30))
            t_rect = text.get_rect(center=rect.center)
            shadow_rect = t_rect.copy()
            shadow_rect.x += 2; shadow_rect.y += 2
            self.screen.blit(shadow, shadow_rect)
            self.screen.blit(text, t_rect)
